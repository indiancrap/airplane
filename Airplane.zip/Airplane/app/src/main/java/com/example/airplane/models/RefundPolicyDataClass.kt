package com.example.airplane.models

data class RefundPolicyDataClass(
        val success: Boolean,
        val data: List<Item>
)

data class Item(
        val charges: String,
        val startDate: String,
        val endDate: String
)