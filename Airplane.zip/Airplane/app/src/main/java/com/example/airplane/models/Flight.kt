package com.example.airplane.models

data class Flight(
    val success: Boolean,
    val data: List<FlightData>
)

data class FlightData(
    val flightName: String,
    val flightNumber: String,
    val startDate: String,
    val startTime: String,
    val endDate: String,
    val endTime: String,
    val flightDuration: String,
    val layoverDetails: LayoverDetails
)

data class LayoverDetails(
    val duration: String,
    val place: String
)