import com.example.airplane.models.Flight
import com.example.airplane.models.RefundPolicyDataClass
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET

interface ApiService {
    @GET("v3/71f75d04-ac3b-4307-ac96-842a2f1bfb95")
    suspend fun getRefundApiResponse(): RefundPolicyDataClass

    @GET("v3/5a28b0ce-eb53-4ded-a269-f568014e7371")
    suspend fun getFlightApiResponse(): Flight
}

object RetrofitClient {
    private const val BASE_URL = "https://run.mocky.io/"

    private val retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    val apiService: ApiService = retrofit.create(ApiService::class.java)
}