package com.example.airplane

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.airplane.databinding.ActivityMainBinding
import com.example.airplane.models.Flight
import com.example.airplane.models.RefundPolicyDataClass

class MainActivity : AppCompatActivity() {

    lateinit var binding: ActivityMainBinding
    private lateinit var viewModel: AirplaneViewModel

    companion object {
        const val SOMETHING_WENT_WRONG = "Something went wrong"
    }

    //https://run.mocky.io/v3/c8e99cb3-bd16-439e-8b07-d56caab2e3b7
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        viewModel = ViewModelProvider(this).get(AirplaneViewModel::class.java)
        viewModel.getRefundPolicyData()
        viewModel.getFlightApiData()
        observerListeners()
    }

    private fun observerListeners() {
        viewModel.refundPolicyLiveData.observe(this) {
            if (it != null) {
                setupUIRefundPolicy(it)
            } else {
                showErrorToast()
            }
        }

        viewModel.flightLiveData.observe(this) {
            if (it != null) {
                setupUIFlight(it)
            } else {
                showErrorToast()
            }
        }

    }

    private fun setupUIFlight(data: Flight) {
        binding.layoverTracker.apply {

        }
    }

    private fun showErrorToast() {
        Toast.makeText(applicationContext, SOMETHING_WENT_WRONG, Toast.LENGTH_SHORT)
            .show()
    }

    private fun setupUIRefundPolicy(refundPolicyData: RefundPolicyDataClass) {
        binding.refundPolicyRV.apply {
            adapter = RefundPolicyAdapter(context, refundPolicyData.data)
            layoutManager = LinearLayoutManager(context, RecyclerView.VERTICAL, false)
        }
    }
}