package com.example.airplane

import RetrofitClient
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.airplane.models.Flight
import com.example.airplane.models.RefundPolicyDataClass
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlin.math.log

class AirplaneViewModel : ViewModel() {

    private var _refundPolicyLiveData = MutableLiveData<RefundPolicyDataClass>()
    var refundPolicyLiveData : LiveData<RefundPolicyDataClass> = _refundPolicyLiveData

    private var _flightLiveData = MutableLiveData<Flight>()
    var flightLiveData : LiveData<Flight> = _flightLiveData

    fun getRefundPolicyData() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val response = RetrofitClient.apiService.getRefundApiResponse()
                _refundPolicyLiveData.postValue(response)
            } catch (e: Exception) {
                // Handle the error here
                _refundPolicyLiveData.postValue(null)
                e.printStackTrace()
            }
        }
    }

    fun getFlightApiData() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val response = RetrofitClient.apiService.getFlightApiResponse()
                _flightLiveData.postValue(response)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }


}